# simple-calendar

This calendar uses [Source Han Code JP](https://github.com/adobe-fonts/source-han-code-jp) font, but it is not included.  
Please install it or change the `font-family` property as you want.